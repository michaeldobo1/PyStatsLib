from pystatslib.continuous import Continuous
from pystatslib.discrete import Discrete
from pystatslib.integration import Integration
from pystatslib.regression import Regression